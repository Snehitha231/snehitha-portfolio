const page = document.documentElement;
const motionButton = document.querySelector(".motion");
const motionLabel = document.querySelector(".motion-label");
const sparkles = document.querySelector(".sparkles");
const reducedMotion = matchMedia("(prefers-reduced-motion: reduce)");
let paused = false;
let scrollQueued = false;
let clickShift = 0;

function updateMotion() {
  motionButton.hidden = reducedMotion.matches;
  motionButton.setAttribute("aria-pressed", String(paused));
  motionLabel.textContent = paused ? "Resume motion" : "Pause motion";
  page.classList.toggle("motion-paused", paused || reducedMotion.matches);
  if (paused || reducedMotion.matches) sparkles.replaceChildren();
}

function updateScrollColor() {
  scrollQueued = false;
  if (paused || reducedMotion.matches) return;
  const range = page.scrollHeight - window.innerHeight;
  const degrees = range > 0 ? Math.round(window.scrollY / range * 95) : 0;
  page.style.setProperty("--scroll-shift", `${degrees}deg`);
}

motionButton.addEventListener("click", () => {
  paused = !paused;
  updateMotion();
  updateScrollColor();
});
reducedMotion.addEventListener("change", () => {
  updateMotion();
  updateScrollColor();
});
window.addEventListener("scroll", () => {
  if (scrollQueued || paused || reducedMotion.matches) return;
  scrollQueued = true;
  requestAnimationFrame(updateScrollColor);
}, { passive: true });

document.addEventListener("click", (event) => {
  if (paused || reducedMotion.matches || motionButton.contains(event.target)) return;
  clickShift = (clickShift + 34) % 360;
  page.style.setProperty("--click-shift", `${clickShift}deg`);
  if (event.detail === 0) return;

  for (const offset of [-32, 0, 32]) {
    const heart = document.createElement("span");
    heart.className = "burst";
    heart.textContent = "♥";
    heart.style.left = `${event.clientX - 8}px`;
    heart.style.top = `${event.clientY - 8}px`;
    heart.style.setProperty("--x", `${offset}px`);
    heart.style.setProperty("--turn", `${offset}deg`);
    heart.addEventListener("animationend", () => heart.remove(), { once: true });
    sparkles.append(heart);
  }
});

updateMotion();
updateScrollColor();
