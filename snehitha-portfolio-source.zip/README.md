# Snehitha’s portfolio

This ZIP contains the HTML, CSS, JavaScript, and assets from the published website. The files can be hosted as a static site without a build step.

## Open it on your computer

1. Extract the ZIP.
2. Open `index.html` in your browser.
3. Keep `index.html`, `styles.css`, `motion.js`, and the `assets` folder together.

## Put the source on GitHub

Upload the extracted files and the `assets` folder to the root of your repository. To track changes locally, run these commands from the extracted folder:

```sh
git init
git add .
git commit -m "Add Snehitha's portfolio"
```
